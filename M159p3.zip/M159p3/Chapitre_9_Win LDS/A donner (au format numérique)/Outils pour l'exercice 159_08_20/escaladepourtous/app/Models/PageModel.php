<?php namespace App\Models;

use SteeveDroz\NanoFramework\Model;

class PageModel extends Model {
    protected $table = 'pages';
}
