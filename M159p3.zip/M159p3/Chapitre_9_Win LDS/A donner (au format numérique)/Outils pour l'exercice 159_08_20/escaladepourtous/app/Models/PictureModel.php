<?php namespace App\Models;

use App\Libraries\Curl;

class PictureModel {
  public function getPictures()
  {
    $pictures = [];
    $handle = opendir(APPPATH.'/../img');
    while (false !== ($entry = readdir($handle))) {
      if (substr($entry, 0, 1) != '.') {
        $nameParts = explode('-', $entry);
        $pictures[] = [
          'url' => '/img/' . $entry,
          'author' => ucfirst($nameParts[0]) . ' ' . ucfirst($nameParts[1])
        ];
      }
    }
    closedir($handle);
    return $pictures;
  }
}
