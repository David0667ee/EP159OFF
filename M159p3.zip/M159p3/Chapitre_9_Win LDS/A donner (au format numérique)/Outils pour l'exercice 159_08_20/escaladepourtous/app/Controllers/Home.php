<?php namespace App\Controllers;

use App\Models\PictureModel;
use SteeveDroz\NanoFramework\DotEnv;

class Home extends BaseController {
    public function index()
    {
      if (!$this->auth->isLoggedIn()) {
        $this->redirect('/login');
      }

      $pictureModel = new PictureModel();
        $this->data['page_title'] = 'Bienvenue';
        $this->data['pictures'] = $pictureModel->getPictures();
        return $this->render();
    }

    public function login()
    {
      $this->data['error'] = '';
      if ($this->isPost()) {
        $user = $this->getPost();
        if ($this->auth->login($user)) {
          $this->redirect('/');
        }
        $this->data['error'] = 'Nom d\'utilisateur ou mot de passe incorrect';
      }
      $this->data['page_title'] = 'Login';
      return $this->render();
    }

    public function logout()
    {
      $this->auth->logout();
      $this->redirect('/');
    }
}
