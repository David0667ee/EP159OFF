<?php namespace App\Controllers;

use App\Libraries\Auth;
use SteeveDroz\NanoFramework\Controller;

abstract class BaseController extends Controller {
  public function __construct()
  {
    $this->auth = new Auth();
    $this->rawData['login'] = $this->auth->isLoggedIn() ? '<a href="/logout">Déconnexion</a>' : '<a href="/login">Connexion</a>';
  }
}
