<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

require __DIR__ . '/vendor/autoload.php';

use SteeveDroz\NanoFramework\DotEnv;
use SteeveDroz\NanoFramework\Route;

// Where the .env file is relative to index.php
DotEnv::setRoot('./');

if (DotEnv::getEnv('ENVIRONMENT', 'development') != 'development') {
    ini_set('display_errors', '0');
    ini_set('display_startup_errors', '0');
    error_reporting(0);
}

if (!defined('APPPATH')) {
    define('APPPATH', __DIR__ . DIRECTORY_SEPARATOR . DotEnv::getEnv('APPPATH', 'app'));
}

if (!defined('FAKEDB_SECRET')) {
    define('FAKEDB_SECRET', DotEnv::getEnv('FAKEDB_SECRET', 'ChangeMeThisIsNotSecret'));
}

// If you have a different file that contains the specific routes,
// you can change or add another file with Route::load()

Route::load('routes');

try {
    Route::display();
} catch(Error $e) {
    Route::analyzeError($e);
    throw $e;
}
