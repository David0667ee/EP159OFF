<?php namespace App\Libraries;

use SteeveDroz\NanoFramework\DotEnv;

class Auth {
  public function login(array $user): bool
  {
	  if ($user['username'] == '' || $user['password'] == '') {
		return false;
	  }
	  $conn = \ldap_connect('ldap://' . DotEnv::getEnv('LDAP_SERVER', ''));

	  if (!$conn) {
		  echo '<div>Erreur de connexion</div>';
		  return false;
	  }
	  
	  if(!\ldap_start_tls($conn)) {
		  echo '<div>Erreur de TLS</div>';
		  return false;
	  }
	  
	  $rdn = 'CN='.$user['username'].',CN=Utilisateurs,DC='.DotEnv::getEnv('LDAP_SITE', '').',DC=Local';
	  $bind = @\ldap_bind($conn, $rdn, $user['password']);
	  
	  if ($bind) {
		  $_SESSION['user'] = $user;
		  return true;
	  }
	  
	  return false;
  }

  public function logout(): void
  {
      unset($_SESSION['user']);
  }

  public function isLoggedIn(): bool
  {
    return array_key_exists('user', $_SESSION);
  }
}
