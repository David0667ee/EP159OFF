<?php

// Eléments d'authentification LDAP
$ldapsrv  = 'SRV-LDS-01'; // On ne peut pas mettre SRV-LDS-01.dmz.local car le certificat est au nom de SRV-LDS-01
// On peut utiliser des SubjectAltName lors de la génération sur Windows ou alors en générer un avec le bon nom drectement

// Test avec l'utilisateur admin
$ldaprdn  = 'CN=admin,CN=Utilisateurs,DC=Escalade,DC=Local';     // DN ou RDN LDAP
$ldappass = 'P@ss1234';  // Mot de passe associé

// Test avec gaston
$ldaprdn  = 'CN=LagaffeGaston,CN=Utilisateurs,DC=Escalade,DC=Local';     // DN ou RDN LDAP
$ldappass = 'Jane4ever';  // Mot de passe associé



// DEBUG
// ldap_set_option(NULL, LDAP_OPT_DEBUG_LEVEL, 7);

print "Connexion au serveur LDAP $ldapsrv" . PHP_EOL;
$ldapconn = ldap_connect("ldap://$ldapsrv") 
	or die("Impossible de se connecter au serveur LDAP.") . PHP_EOL;

print "Passe en version 3" . PHP_EOL;
ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);


print "Démarre la connexion sécurisée" . PHP_EOL;
if(!ldap_start_tls($ldapconn)) {
    print ldap_error($ldapconn);
    exit;
}


if ($ldapconn) {
    print "Bind au serveur LDAP avec $ldaprdn et **************" . PHP_EOL;
    $ldapbind = ldap_bind($ldapconn, $ldaprdn, $ldappass);

    // Vérification de l'authentification
    if ($ldapbind) {
        echo "Connexion LDAP réussie..." . PHP_EOL;
	// limit attributes we want to look for
	$attributes_ad = [ "distinguishedName" ];
	// define base
	$base ="CN=Utilisateurs,DC=Escalade,DC=Local";

	// in my script I search based on e-mail, $email variable is passed from the form
	$result = ldap_search($ldapconn, $base, "cn=*", $attributes_ad) or die ("Error in search query");

	// put search results into the array ($conn variable is defined in the included 'ad_con.php')
	$info = ldap_get_entries($ldapconn, $result);

	//Now, to display the results we want:
	for ($i=0; $i<$info["count"]; $i++) {
		// to show the attribute displayName (note the case!)
		print $info[$i]["distinguishedname"][0] . PHP_EOL;
	}
    } else {
        echo "Connexion LDAP échouée..." . PHP_EOL;
    }

}

