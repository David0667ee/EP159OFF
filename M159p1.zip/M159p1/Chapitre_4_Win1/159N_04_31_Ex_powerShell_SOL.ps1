import-module ActiveDirectory
#
# 159_04 : Cr�er les UO de l'entreprise Gazdici.
#
if ((Get-ADOrganizationalUnit -Filter {Name -eq "GazDici"}) -eq $null)
{ 
 New-ADOrganizationalUnit -Name GazDici -Path "dc=eureka,dc=local"
 Write-Host "UO GazDici cr��e !!!"
} else {Write-Host "UO GazDici d�j� cr��e !!!"}

if ((Get-ADOrganizationalUnit -Filter {Name -eq "ARGroupeLocaux"}) -eq $null)
{ 
 New-ADOrganizationalUnit -Name ARGroupesLocaux -Path "ou=GazDici,dc=eureka,dc=local"
 Write-Host "UO ARGroupesLocaux cr��e !!!"
} else {Write-Host "UO ARGroupesLocaux d�j� cr��e !!!"}

if ((Get-ADOrganizationalUnit -Filter {Name -eq "Administration"}) -eq $null)
{ 
 New-ADOrganizationalUnit -Name Administration -Path "ou=GazDici,dc=eureka,dc=local"
 Write-Host "UO Administration cr��e !!!"
} else {Write-Host "UO Administration d�j� cr��e !!!"}

if ((Get-ADOrganizationalUnit -Filter {Name -eq "Direction"}) -eq $null)
{ 
 New-ADOrganizationalUnit -Name Direction -Path "ou=Administration,ou=GazDici,dc=eureka,dc=local"
 Write-Host "UO Direction cr��e !!!"
} else {Write-Host "UO Direction d�j� cr��e !!!"}


#
# Cr�er les utilisateurs
#
if ((Get-ADUser -Filter {SAMAccountName -eq "BossJ"}) -eq $null)
{
  New-ADUser -name "Boss Joe" -Surname "Boss" -GivenName "Joe" -DisplayName "Boss Joe" -SamAccountName "BossJ" -UserPrincipalName "BossJ" -AccountPassword (ConvertTo-SecureString "bossj" -asplaintext -force) -CannotChangePassword $true -Enabled $true -path "ou=Direction,ou=Administration,ou=GazDici,dc=eureka,dc=local"
  Write-Host "L'utilisateur Boss Joe a �t� cr�� !!!"
} else {Write-Host "L'utilisateur Boss Joe n'a pas pu �tre cr�� !!!"}


#
# Cr�er le groupe global et le groupe local
# et mettre les membres du groupe
#
if ((Get-ADGroup -Filter {Name -eq "GG_Direction"}) -eq $null)
{
  New-ADGroup -name "GG_Direction" -GroupScope Global -Path "ou=Direction,ou=Administration,ou=GazDici,dc=eureka,dc=local"
  Add-ADGroupMember -Identity "GG_Direction" -Members "BossJ"
} else {Write-Host "Le groupe GG_Direction n'a pas peu �tre cr�� !!!"}

if ((Get-ADGroup -Filter {Name -eq "GL_BDir_M"}) -eq $null)
{
  New-ADGroup -name "GL_BDir_M" -GroupScope DomainLocal -Path "ou=ARGroupesLocaux,ou=GazDici,dc=eureka,dc=local"
  Add-ADGroupMember -Identity "GL_BDir_M" -Members "GG_Direction"
} else {Write-Host "Le groupe GL_BDir_M n'a pas peu �tre cr�� !!!"}

